#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setCentralWidget(ui->textEdit);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionNew_triggered()
{
    currentfile.clear();
    ui->textEdit->setText(QString());
}

void MainWindow::on_actionOpen_triggered()
{
    QString filename = QFileDialog::getOpenFileName(this,"open the file");
    QFile file(filename);
    currentfile=filename;
    if(!file.open(QIODevice::ReadOnly | QFile::Text)){
        QMessageBox:: warning(this,"warning","cannot open file :"+ file.errorString());
         return;
    }
    setWindowTitle(filename);
    QTextStream in(&file);
    QString text=in.readAll();
    ui->textEdit->setText(text);
    file.close();
}


void MainWindow::on_actionsave_as_triggered()
{
    QString filename=QFileDialog::getSaveFileName(this,"save as");
    QFile file(filename);
    if(!file.open(QFile::WriteOnly | QFile::Text)){
        QMessageBox::warning(this,"Warning","cannot open the file :"+ file.errorString());
        return;
    }
     currentfile=filename;
     setWindowTitle(filename);
     QTextStream out(&file);
     QString text=ui->textEdit->toPlainText();
     out<<text;
     file.close();
}

void MainWindow::on_actioncopy_triggered()
{
    ui->textEdit->copy();
}

void MainWindow::on_actionpaste_triggered()
{
        ui->textEdit->paste();
}

void MainWindow::on_actioncut_triggered()
{
        ui->textEdit->cut();
}

void MainWindow::on_actionAbout_QT_triggered()
{
      QMessageBox ::aboutQt(this,"about QT");
}


