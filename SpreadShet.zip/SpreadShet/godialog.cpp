#include "godialog.h"
#include "ui_godialog.h"

GoDialog::GoDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::GoDialog)
{
    ui->setupUi(this);
    //Validating the regular expression
    QRegExp regCell{"[A-Z][1-9][0-9]{0,2}"};

    //Validating the regular expression
    ui->lineEdit->setValidator(new QRegExpValidator(regCell));
}

GoDialog::~GoDialog()
{
    delete ui;
}
QString GoDialog::gocell() const
  {
      return ui->lineEdit->text();
  }
