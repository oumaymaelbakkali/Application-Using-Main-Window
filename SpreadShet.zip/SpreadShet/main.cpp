#include "spreadsheet.h"

#include <QApplication>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    spreadsheet w;
    QPixmap Icon(":/spreadshet.png");
    w.setWindowIcon(Icon);
    w.setWindowTitle("SpredSheet");

    w.show();
    return a.exec();
}
