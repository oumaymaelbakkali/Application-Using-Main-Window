#ifndef GODIALOG_H
#define GODIALOG_H

#include <QDialog>
#include<QRegularExpression>
#include<QRegExpValidator>

namespace Ui {
class GoDialog;
}

class GoDialog : public QDialog
{
    Q_OBJECT

public:
    explicit GoDialog(QWidget *parent = nullptr);
    ~GoDialog();
     QString gocell()const;

private:
    Ui::GoDialog *ui;
};

#endif // GODIALOG_H
