#ifndef SPREADSHEET_H
#define SPREADSHEET_H
#include <QMainWindow>
#include<QTableWidget>
#include<QAction>
#include<QMenu>
#include<QMenuBar>
#include<QMessageBox>
#include<QCheckBox>
#include<QToolBar>
#include<QLabel>
#include<QStatusBar>
#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class spreadsheet; }
QT_END_NAMESPACE

class spreadsheet : public QMainWindow
{
    Q_OBJECT

public:
    spreadsheet(QWidget *parent = nullptr);
    ~spreadsheet();

private:
    // CENTRAL WIDGETS
    QTableWidget *Spreadsheet;


    QAction *quit;
    QAction *NewFile;
    QAction *SaveFile;
    QAction *openFile;
    QAction *SaveasFile;
    QAction *About;
    QAction *Cut;
    QAction *Copy;
    QAction *paste;
    QAction *delet;
    QAction *select;
    QAction *find;
    QAction *Recalculate;
    QAction *auto_Recalculate;
    QAction *show_Grid;
    QAction *sort;
    QAction *Ab;
    QAction *goCell;
    QAction *deleteAction;


    QMenu  *file;
    QMenu *Edit;
    QMenu *Tools;
    QMenu *Option;
    QMenu *help;
    QAction *Row;
    QAction *column;
    QAction *all;
    //widgets pour la barres
    QLabel *cellLocation;
    QLabel *cellFormation;




protected:
    void createActions();
    void createMenus();
    void creatToolBar();
    void makeconnections();


//    void setupMainWidget();
    void updatestatutbar(int,int);//responds for to call changed
public slots:
    void infoAbout();
    void goCellSlot();
    void finddialog();
protected:
    void saveContent(QString filename)const;
private slots:
    void saveSlot();
    void loadSlot();
    void NewSlot();



private:
    Ui::spreadsheet *ui;
   QString currentfile="";
};
#endif // SPREADSHEET_H
