#include "spreadsheet.h"
#include "ui_spreadsheet.h"
#include"godialog.h"
#include"dialog.h"
#include<QFile>
#include<QTextStream>
#include<QFileDialog>
#include<QDataStream>

spreadsheet::spreadsheet(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::spreadsheet)
{
    Spreadsheet=new QTableWidget;
    Spreadsheet->setColumnCount(20);
    Spreadsheet->setRowCount(20);
    setCentralWidget(Spreadsheet);



   //seting the spreadsheet
    //creating actions
    createActions();

    //creating Menu
     createMenus();

    //creating the tool bar
     creatToolBar();

     //make connection
      makeconnections();

    cellLocation=new QLabel("(1,1)");
    cellFormation=new QLabel("");
    statusBar()->addPermanentWidget(cellLocation);
    statusBar()->addPermanentWidget(cellFormation);


//    //construire les labels verticaux
//    QStringList labels;
//    for(auto letter = 'A';letter<= 'Z';letter++)
//        labels<<QString(letter);
//    Spreadsheet->setVerticalHeaderLabels(labels);
}

spreadsheet::~spreadsheet()
{
    delete Spreadsheet;
    delete quit;
    delete NewFile;
    delete SaveFile;
    delete About;
    delete Cut;
    delete file;
    delete help;
    delete openFile;
    delete find;
    delete cellFormation;
    delete cellLocation;
    delete sort;
    delete Recalculate;
    delete auto_Recalculate;
    delete Ab;
    delete SaveasFile;
    delete show_Grid;
    delete find;
}
void spreadsheet::createActions(){
    //action new file
   QPixmap newtIcon(":/new-file.png");
   NewFile=new QAction(newtIcon,"New &File",this);
   NewFile->setShortcut(tr("Ctrl+N"));

   //action open file
   QPixmap openIcon(":/open.png");
   openFile = new QAction(openIcon,"Open",this);
   openFile->setShortcut(tr("Ctrl+N"));

   //action save file
   QPixmap saveIcon(":/save.png");
   SaveFile=new QAction(saveIcon,"Save &File",this);
   SaveFile->setShortcut(tr("Ctrl+S"));

   SaveasFile=new QAction("&Save as....",this);

  //lui choisir une icone
   QPixmap quitIcon(":/quit.png");
  //lui choisir un nom
   quit=new QAction(quitIcon,"&Quit",this);
  //lui choisir un reccoursi
   quit->setShortcut(tr("Ctrl+Q"));


  QPixmap cutIcon(":/cut.png");
  Cut=new QAction(cutIcon,"&cut",this);
  Cut->setShortcut(tr("Ctrl+X"));

  QPixmap copyIcon(":/copy.png");
  Copy=new QAction(copyIcon,"Copy",this);
  Copy->setShortcut(tr("Ctrl+C"));


  QPixmap pastIcon(":/paste.png");
  paste=new QAction(pastIcon,"&Paste",this);
  paste->setShortcut(tr("Ctrl+V"));

  QPixmap searchIcon(":/search.png");
  find=new QAction(searchIcon,"&find...",this);
  find->setShortcut(tr("Ctrl+F"));

  QPixmap goIcon(":/go.png");
  goCell=new QAction(goIcon,"&Go to cell...",this);
  goCell->setShortcut(tr("F5"));


  Recalculate=new QAction("&Recalculate",this);
  Recalculate->setShortcut(tr("F9"));
  sort=new QAction("&sort");

  show_Grid= new QAction("&show Grid");
  show_Grid->setCheckable(true);
  show_Grid->setChecked(Spreadsheet->showGrid());


    auto_Recalculate=new QAction("&Auto Recalculate",this);
    auto_Recalculate->setCheckable(true);
    auto_Recalculate->setChecked(true);

   QPixmap deletIcon(":/delete.png");
   delet=new QAction(deletIcon,"Delete",this);
   delet->setShortcut(tr("del"));



  //action about QT
   QPixmap qtIcon(":/qt.png");
   About= new QAction(qtIcon,"&AboutQT",this);

   QPixmap aboutIcon(":/about.png");
   Ab= new QAction(aboutIcon,"&About",this);

   select= new QAction("&Select");
   Row=new QAction("&Row");
   column=new QAction("&column");
   all=new QAction("&All",this);
   all->setShortcut(tr("Ctrl+A"));



}
void spreadsheet::createMenus(){
    file = menuBar()->addMenu("&File");
    file->addAction(NewFile);
    file->addAction(openFile);
    file->addAction(SaveFile);
    file->addAction(SaveasFile);
    file->addAction(quit);

   Edit= menuBar()->addMenu("&Edit");
   Edit->addAction(Cut);
   Edit->addAction(Copy);
   Edit->addAction(paste);
   Edit->addAction(delet);
   auto submenu = Edit->addMenu("&select");
   submenu->addAction(Row);
   submenu->addAction(column);
   submenu->addAction(all);
   Edit->addAction(find);
   Edit->addAction( goCell);





    Tools=menuBar()->addMenu("&Tools");
    Tools->addAction(Recalculate);
    Tools->addAction(sort);


    Option=menuBar()->addMenu("&option");
    Option->addAction(show_Grid);
    Option->addAction(auto_Recalculate);



     help = menuBar()->addMenu("&Help");
     help->addAction(Ab);
     help->addAction(About);




}
void spreadsheet::infoAbout(){
     QMessageBox ::aboutQt(this,"about QT");
}
void spreadsheet::creatToolBar(){
    auto tool1=addToolBar("File");
    tool1->addAction(NewFile);
    tool1->addAction(SaveFile);
    tool1->addSeparator();
    tool1->addAction(quit);

    //cree une autre tool Bar
    auto tool2=addToolBar("Edit");
    tool2->addAction(find);
}
void spreadsheet::updatestatutbar(int row,int col){
    QString cell{"(%0,%1)"};
    cellLocation->setText(cell.arg(row+1).arg(col+1));

}
void spreadsheet::goCellSlot()
 {
     //Creating the dialog
     GoDialog D;
      //Executing the dialog and storing the user response
     auto reply = D.exec();
      //Checking if the dialog is accepted

     if(reply == GoDialog::Accepted)
     { //Getting the cell text
         auto cell = D.gocell();
           //letter distance
         int row = cell[0].toLatin1() - 'A';
         cell.remove(0,1);
          //second coordinate
         int col =  cell.toInt();
          //changing the current cell
         Spreadsheet->setCurrentCell(row, col-1);
     }
 }
void spreadsheet::finddialog(){
    Dialog D;
    auto replay=D.exec();
    if(replay== QDialog::Accepted){

        auto pattern =D.findcell();

        for(int i=0;i<Spreadsheet->rowCount();i++)
            for(int j=0;j<Spreadsheet->colorCount();j++){
                auto content = Spreadsheet->item(i,j);

              }
    }
}
void spreadsheet::saveContent(QString filename) const
 {

     //Gettign a pointer on the file
     QFile file(filename);

     //Openign the file
     if(file.open(QIODevice::WriteOnly))  //Opening the file in writing mode
     {
         //Initiating a stream using the file
         QTextStream out(&file);

         //loop to save all the content
         for(int i=0; i < Spreadsheet->rowCount();i++)
             for(int j=0; j < Spreadsheet->columnCount(); j++)
             {
                 auto cell = Spreadsheet->item(i, j);

                 //Cecking if the cell is non empty
                 if(cell)
                 out << cell->row() << ", "<< cell->column() << ", " << cell->text() << endl;
             }

     }
     file.close();
 }
void spreadsheet::saveSlot(){
    QString currentFile=nullptr;

   //Creating a file dialog to choose a file graphically
   auto dialog = new QFileDialog(this);

   //Check if the current file has a name or not
   if(currentFile == "")
   {
      currentFile = dialog->getSaveFileName(this,"choose your file");

      //Update the window title with the file name
      setWindowTitle(currentFile);
   }

  //If we have a name simply save the content
  if( currentFile != "")
  {
          saveContent(currentFile);
  }
}
void spreadsheet::loadSlot(){
    Spreadsheet->clear();
    QString filename = QFileDialog::getOpenFileName(this,"open the file");
    QFile file(filename);
    currentfile=filename;
    if(!file.open(QIODevice::ReadOnly | QFile::Text)){
        QMessageBox:: warning(this,"warning","cannot open file :"+ file.errorString());
         return;
    }
    setWindowTitle(filename);
    QTextStream in(&file);

    while(!in.atEnd()){
    QString text=in.readLine();
    QStringList columns=text.split(",");
    for(int j=0;j<columns.size();j++){
      QTableWidgetItem *item= new QTableWidgetItem(columns[2]);
      int k=columns[0].toInt();
      int b=columns[1].toInt();
      Spreadsheet->setItem(k,b,item);
      }
    file.close();

}
}
void spreadsheet::NewSlot(){
    Spreadsheet->clear();

}
void spreadsheet::makeconnections()
{
connect(About,&QAction::triggered,this,&spreadsheet::infoAbout);
// --------- Connexion for the  select all action ----/
connect(all, &QAction::triggered,Spreadsheet, &QTableWidget::selectAll);

// Connection for the  show grid
connect(show_Grid, &QAction::triggered,Spreadsheet, &QTableWidget::setShowGrid);

//Connection for the exit button
connect(quit, &QAction::triggered, this, &spreadsheet::close);

//connectting the chane of any element in the spreadsheet with the update status bar
connect(Spreadsheet,&QTableWidget::cellClicked, this,&spreadsheet::updatestatutbar);
//Connextion between the gocell action and the gocell slot
connect(goCell, &QAction::triggered, this, &spreadsheet::goCellSlot);
//Connextion between the search action and the finddialog slot
connect(find,&QAction::triggered,this,&spreadsheet::finddialog);
//Connexion for the saveFile
 connect(SaveFile, &QAction::triggered, this, &spreadsheet::saveSlot);
 //connexion for load File
 connect(openFile,&QAction::triggered,this,&spreadsheet::loadSlot);
 //connexion for New File
 connect(NewFile,&QAction::triggered,this,&spreadsheet::NewSlot);

}

